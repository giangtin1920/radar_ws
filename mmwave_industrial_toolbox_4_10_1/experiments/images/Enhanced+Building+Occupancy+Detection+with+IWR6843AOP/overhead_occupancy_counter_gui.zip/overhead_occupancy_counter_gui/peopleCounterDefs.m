classdef peopleCounterDefs
    properties (Constant = true)
        % Target region definitions
        UNKNOWN_REGION = 0;
        REGION_1 = 1;
        REGION_2 = 2;
        REGION_3 = 3;
        
        % Target state definitions
        UNKNOWN_STATE = -1;
        INCOMING_DETECTED = -2;
        INCOMING = -3;
        ENTERED  = -4;
        OUTGOING_DETECTED = -5;
        OUTGOING = -6;
        EXITED = -7;    
    end
end
